// http://www.cs.colby.edu/maxwell/courses/tutorials/maketutor/
// para compilar:
// gcc hello.c hello-header.c -o hello

#include "hello-header.h"

int main() {
  // call a function in another file
  myPrintHelloMake();
  

  return(0);
}
