#include<stdio.h>
#include "hello-header.h"

void myPrintHelloMake(void) {

  printf("Hello makefiles!\n");

}
