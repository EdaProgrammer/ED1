#include "f1.h"
#include "f2.h"

int main(){
  a();
  b();
  return 0;
}
