#include<stdio.h>
#include"f3.h"

void c(){
  printf("\n funcao de f3 %d", MAX);
}
