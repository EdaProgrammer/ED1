#ifndef F3_H
#define F3_H

#define MAX 100

void c();

#endif
