#include<stdio.h>
#include "f3.h"

void b(){
  printf("\n estou na funcao de f2");
  printf("\nvalor definido na funcao f3: %d", MAX);
}
